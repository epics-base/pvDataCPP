/*dataMain.cpp */
/**
 * Copyright - See the COPYRIGHT that is included with this distribution.
 * EPICS pvData is distributed subject to a Software License Agreement found
 * in file LICENSE that is included with this distribution.
 */
/**
 * @author mrk
 */

/* Author: Marty Kraimer */

#include <cstddef>
#include <cstdlib>
#include <cstddef>
#include <string>
#include <cstdio>
#include <memory>
#include <iostream>

#include <pv/sharedVector.h>
#include <pv/pvIntrospect.h>
#include <pv/pvData.h>
#include <pv/standardField.h>
#include <pv/standardPVField.h>

using namespace std;
using std::tr1::static_pointer_cast;
using namespace epics::pvData;

static String builder;
static FieldCreatePtr fieldCreate = getFieldCreate();
static PVDataCreatePtr pvDataCreate = getPVDataCreate();
static StandardFieldPtr standardField = getStandardField();
static StructureConstPtr alarm = getStandardField()->alarm();
static StructureConstPtr timeStamp = getStandardField()->timeStamp();

static void doubleValueExample()
{
    cout << "doubleValueExample\n";
    PVStructurePtr doubleValue = getPVDataCreate()->createPVStructure(
        getStandardField()->scalar(pvDouble,"alarm,timeStamp"));
    PVDoublePtr pvdouble = doubleValue->getSubField<PVDouble>("value");
    pvdouble->put(1e5);
    cout << doubleValue->dumpValue(cout) << endl;
    double value = doubleValue->getSubField<PVDouble>("value")->get();
    cout << "from get " << value << "\n\n";
}

static void doubleArrayValueExample()
{
    cout << "doubleArrayValueExample\n";
    PVStructurePtr doubleArrayValue = getPVDataCreate()->createPVStructure(
        getStandardField()->scalarArray(pvDouble,"alarm,timeStamp"));
    PVDoubleArrayPtr pvDoubleArray = doubleArrayValue->getSubField<PVDoubleArray>("value");
    size_t len = 10;
    shared_vector<double> xxx(len);
    for(size_t i=0; i< len; ++i) xxx[i] = i;
    shared_vector<const double> data(freeze(xxx));
    pvDoubleArray->replace(data);
    cout << doubleArrayValue->dumpValue(cout) << endl;
    shared_vector<const double>  getData = pvDoubleArray->view();
    cout << "via getData";
    for (size_t i=0; i< len; ++i) cout << " " << getData[i];
    cout << "\n\n";
}

static void enumExample()
{
    cout << "enumExample\n";
    PVStructurePtr pvntenum = getPVDataCreate()->createPVStructure(
         getStandardField()->enumerated("alarm,timeStamp"));
    cout << pvntenum->dumpValue(cout) << "\n\n";
}

static void powerSupplyExample()
{
    cout << "powerSupplyExample\n";
    StructureConstPtr powerSupply =
    getFieldCreate()->createFieldBuilder()->
        add("alarm_t",alarm) ->
        add("timestamp_t",timeStamp) ->
        addNestedStructure("power") ->
           add("value",pvDouble) ->
           add("alarm",alarm) ->
           endNested()->
        addNestedStructure("voltage") ->
           add("value",pvDouble) ->
           add("alarm",alarm) ->
           endNested()->
        addNestedStructure("current") ->
           add("value",pvDouble) ->
           add("alarm",alarm) ->
           endNested()->
        createStructure();
    PVStructurePtr pvpowerSupply = getPVDataCreate()->createPVStructure(powerSupply);
    cout << pvpowerSupply->dumpValue(cout) << endl;
}

static void unionExample()
{
    cout << "unionExample\n";
    PVStructurePtr pvStructure = pvDataCreate->createPVStructure(
        standardField->regUnion(
            getFieldCreate()->createFieldBuilder()->
                add("doubleValue", pvDouble)->
                add("intValue", pvInt)->
                add("timeStamp",timeStamp)->
                createUnion(),
            "alarm,timeStamp"));
    PVStructurePtr pvTimeStamp = pvStructure->getSubField<PVUnion>("value")->select<PVStructure>(2);
    pvTimeStamp->getSubField<PVLong>("secondsPastEpoch")->put(1000);
    cout << pvStructure->dumpValue(cout) << "\n";
    pvStructure->getSubField<PVUnion>("value")->select<PVDouble>(0)->put(1e5);
    cout << pvStructure->dumpValue(cout) << "\n\n";
}

static void varientUnionExample()
{
    cout << "varientUnionExample\n";
    PVStructurePtr pvStructure = pvDataCreate->createPVStructure(
        standardField->variantUnion("alarm,timeStamp"));
    PVStructurePtr pvTimeStamp = pvDataCreate->createPVStructure(standardField->timeStamp());
    pvStructure->getSubField<PVUnion>("value")->set(pvTimeStamp);
    pvTimeStamp->getSubField<PVLong>("secondsPastEpoch")->put(1000);
    cout << pvStructure->dumpValue(cout) << "\n";
    pvStructure->getSubField<PVUnion>("value")->set(pvDataCreate->createPVScalar(pvDouble));
    PVDoublePtr pvValue = static_pointer_cast<PVDouble>(
        pvStructure->getSubField<PVUnion>("value")->get());
    pvValue->put(1e5);
    cout << pvStructure->dumpValue(cout) << "\n\n";
}

static void bigUnionExample()
{
    cout << "bigUnionExample\n";
    PVStructurePtr pvStructure = pvDataCreate->createPVStructure(
        standardField->regUnion(
            getFieldCreate()->createFieldBuilder()->
                add("doubleValue", pvDouble)->
                addArray("doubleArrayValue",pvDouble)->
                addNestedUnion("unionValue") ->
                    add("doubleValue", pvDouble)->
                    add("alarm",standardField->alarm()) ->
                    endNested() ->
                addNestedStructure("structValue") ->
                    add("doubleValue", pvDouble)->
                    addArray("doubleArrayValue",pvDouble)->
                    endNested() ->
                addNestedUnionArray("unionArrayValue") ->
                    add("doubleValue", pvDouble)->
                    add("alarm",standardField->alarm()) ->
                    endNested() ->
                addNestedStructureArray("structArrayValue") ->
                    add("doubleValue", pvDouble)->
                    addArray("doubleArrayValue",pvDouble)->
                    endNested() ->
                createUnion(),
            "alarm,timeStamp"));
    builder.clear();
    pvStructure->getStructure()->toString(&builder);
    cout << "introspection\n";
    cout << builder << endl;
    cout << "data\n";
    cout << pvStructure->dumpValue(cout) << "\n";
    PVUnionPtr pvUnion = pvStructure->getSubField<PVUnion>("value");;
    pvUnion->select("doubleValue");
    PVDoublePtr pvDouble = pvUnion->get<PVDouble>();
    pvDouble->put(1.55);
    cout << "select valueDouble\n";
    cout << pvStructure->dumpValue(cout) << "\n";
    cout << "value = " << pvDouble->get() << "\n";
    pvUnion->select("structValue");
    pvDouble = pvUnion->get<PVStructure>()->getSubField<PVDouble>("doubleValue");
    pvDouble->put(1.65);
    cout << "select structValue\n";
    cout << pvStructure->dumpValue(cout) << "\n";
    cout << "value = " << pvDouble->get() << "\n";
}


int main(int argc,char *argv[])
{
    doubleValueExample();
    doubleArrayValueExample();
    enumExample();
    powerSupplyExample();
    unionExample();
    varientUnionExample();
    bigUnionExample();
    return 0;
}
