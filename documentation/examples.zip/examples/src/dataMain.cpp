/*dataMain.cpp */
/**
 * Copyright - See the COPYRIGHT that is included with this distribution.
 * EPICS pvData is distributed subject to a Software License Agreement found
 * in file LICENSE that is included with this distribution.
 */
/**
 * @author mrk
 */

/* Author: Marty Kraimer */

#include <cstddef>
#include <cstdlib>
#include <cstddef>
#include <string>
#include <cstdio>
#include <memory>
#include <iostream>

#include <pv/sharedVector.h>
#include <pv/pvIntrospect.h>
#include <pv/pvData.h>
#include <pv/standardField.h>
#include <pv/standardPVField.h>

using std::cout;
using std::endl;
using namespace epics::pvData;

static FieldCreatePtr fieldCreate = getFieldCreate();
static PVDataCreatePtr pvDataCreate = getPVDataCreate();
static StandardFieldPtr standardField = getStandardField();

static void doubleValueExample()
{
    cout << "doubleValueExample\n";
    PVStructurePtr doubleValue = pvDataCreate->createPVStructure(
        standardField->scalar(pvDouble,"alarm,timeStamp"));
    PVDoublePtr pvdouble = doubleValue->getSubField<PVDouble>("value");
    pvdouble->put(1e5);
    cout << *doubleValue << endl;
    double value = doubleValue->getSubField<PVDouble>("value")->get();
    cout << "from get " << value << "\n\n";
}

static void doubleArrayValueExample()
{
    cout << "doubleArrayValueExample\n";
    PVStructurePtr doubleArrayValue = pvDataCreate->createPVStructure(
        standardField->scalarArray(pvDouble,"alarm,timeStamp"));
    PVDoubleArrayPtr pvDoubleArray = doubleArrayValue->getSubField<PVDoubleArray>("value");
    size_t len = 10;
    shared_vector<double> xxx(len);
    for(size_t i=0; i< len; ++i) xxx[i] = i;
    shared_vector<const double> data(freeze(xxx));
    pvDoubleArray->replace(data);
    cout << *doubleArrayValue << endl;
    shared_vector<const double>  getData = pvDoubleArray->view();
    cout << "via getData";
    for (size_t i=0; i< len; ++i) cout << " " << getData[i];
    cout << "\n\n";
}

static void enumExample()
{
    cout << "enumExample\n";
    PVStructurePtr pvntenum = pvDataCreate->createPVStructure(
         standardField->enumerated("alarm,timeStamp"));
    cout << *pvntenum << "\n\n";
}

static void powerSupplyExample()
{
    cout << "powerSupplyExample\n";
    StructureConstPtr powerSupply =
    fieldCreate->createFieldBuilder()->
        add("alarm",standardField->alarm()) ->
        add("timestamp",standardField->timeStamp()) ->
        addNestedStructure("power") ->
           add("value",pvDouble) ->
           add("alarm",standardField->alarm()) ->
           endNested()->
        addNestedStructure("voltage") ->
           add("value",pvDouble) ->
           add("alarm",standardField->alarm()) ->
           endNested()->
        addNestedStructure("current") ->
           add("value",pvDouble) ->
           add("alarm",standardField->alarm()) ->
           endNested()->
        createStructure();
    PVStructurePtr pvpowerSupply = pvDataCreate->createPVStructure(powerSupply);
    cout << *pvpowerSupply << endl;
}

static void unionExample()
{
    cout << "unionExample\n";
    PVStructurePtr pvStructure = pvDataCreate->createPVStructure(
        standardField->regUnion(
            fieldCreate->createFieldBuilder()->
                add("doubleValue", pvDouble)->
                add("intValue", pvInt)->
                add("timeStamp",standardField->timeStamp())->
                createUnion(),
            "alarm,timeStamp"));
    PVStructurePtr pvTimeStamp = pvStructure->getSubField<PVUnion>("value")->select<PVStructure>(2);
    pvTimeStamp->getSubField<PVLong>("secondsPastEpoch")->put(1000);
    cout << *pvStructure << "\n";
    pvStructure->getSubField<PVUnion>("value")->select<PVDouble>(0)->put(1e5);
    cout << *pvStructure << "\n\n";
}

static void varientUnionExample()
{
    cout << "varientUnionExample\n";
    PVStructurePtr pvStructure = pvDataCreate->createPVStructure(
        standardField->variantUnion("alarm,timeStamp"));
    PVStructurePtr pvTimeStamp = pvDataCreate->createPVStructure(standardField->timeStamp());
    pvStructure->getSubField<PVUnion>("value")->set(pvTimeStamp);
    pvTimeStamp->getSubField<PVLong>("secondsPastEpoch")->put(1000);
    cout << *pvStructure << "\n";
    pvStructure->getSubField<PVUnion>("value")->set(pvDataCreate->createPVScalar(pvDouble));
    PVDoublePtr pvValue = pvDataCreate->createPVScalar<PVDouble>();
    pvValue->put(1e5);
    pvStructure->getSubField<PVUnion>("value")->set(pvValue);
    cout << *pvStructure << "\n\n";
}

static void bigUnionExample()
{
    cout << "bigUnionExample\n";
    PVStructurePtr pvStructure = pvDataCreate->createPVStructure(
        standardField->regUnion(
            fieldCreate->createFieldBuilder()->
                add("doubleValue", pvDouble)->
                addArray("doubleArrayValue",pvDouble)->
                addNestedUnion("unionValue") ->
                    add("doubleValue", pvDouble)->
                    add("alarm",standardField->alarm()) ->
                    endNested() ->
                addNestedStructure("structValue") ->
                    add("doubleValue", pvDouble)->
                    addArray("doubleArrayValue",pvDouble)->
                    endNested() ->
                addNestedUnionArray("unionArrayValue") ->
                    add("doubleValue", pvDouble)->
                    add("alarm",standardField->alarm()) ->
                    endNested() ->
                addNestedStructureArray("structArrayValue") ->
                    add("doubleValue", pvDouble)->
                    addArray("doubleArrayValue",pvDouble)->
                    endNested() ->
                createUnion(),
            "alarm,timeStamp"));
    cout << "introspection\n";
    cout << *pvStructure->getStructure() << endl;
    cout << "data\n";
    cout << *pvStructure << "\n";
    PVUnionPtr pvUnion = pvStructure->getSubField<PVUnion>("value");;
    pvUnion->select("doubleValue");
    PVDoublePtr pvDouble = pvUnion->get<PVDouble>();
    pvDouble->put(1.55);
    cout << "select valueDouble\n";
    cout << *pvStructure << "\n";
    cout << "value = " << pvDouble->get() << "\n";
    pvUnion->select("structValue");
    pvDouble = pvUnion->get<PVStructure>()->getSubField<PVDouble>("doubleValue");
    pvDouble->put(1.65);
    cout << "select structValue\n";
    cout << *pvStructure << "\n";
    cout << "value = " << pvDouble->get() << "\n";
}

static void varientUnionArrayExample()
{
    cout << "varientUnionArrayExample\n";
    PVStructurePtr pvStructure = pvDataCreate->createPVStructure(
        standardField->unionArray(fieldCreate->createVariantUnion(),"alarm,timeStamp"));
    size_t len = 2;
    shared_vector<PVUnionPtr> values(len);
    for(size_t i=0; i<len; ++i) {
        values[i] = pvDataCreate->createPVVariantUnion();
    }
    PVDoublePtr pvDouble = pvDataCreate->createPVScalar<PVDouble>();
    pvDouble->put(1.245);
    values[1] = pvDataCreate->createPVVariantUnion();
    values[1]->set(pvDouble);
    PVUnionArrayPtr pvUnionArray = pvStructure->getSubField<PVUnionArray>("value");
    pvUnionArray->replace(freeze(values));
    cout << *pvStructure << "\n";
    shared_vector<const PVUnionPtr> sharedValues = pvUnionArray->view();
    const PVUnionPtr pvUnion = sharedValues[1];
    PVFieldPtr pvField = pvUnion->get();
    cout << "values[1] = ";
pvDouble->put(111111.0);
    cout << *pvUnionArray << endl;
}


int main(int argc,char *argv[])
{
    doubleValueExample();
    doubleArrayValueExample();
    enumExample();
    powerSupplyExample();
    unionExample();
    varientUnionExample();
    bigUnionExample();
    varientUnionArrayExample();
    return 0;
}
