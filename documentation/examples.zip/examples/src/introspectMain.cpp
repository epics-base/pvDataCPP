/*introspectMain.cpp */
/**
 * Copyright - See the COPYRIGHT that is included with this distribution.
 * EPICS pvData is distributed subject to a Software License Agreement found
 * in file LICENSE that is included with this distribution.
 */
/**
 * @author mrk
 */

/* Author: Marty Kraimer */

#include <cstddef>
#include <cstdlib>
#include <cstddef>
#include <string>
#include <cstdio>
#include <memory>
#include <iostream>

#include <pv/pvIntrospect.h>
#include <pv/pvData.h>
#include <pv/standardField.h>

using namespace std;
using std::tr1::static_pointer_cast;
using namespace epics::pvData;
static String builder;
static StructureConstPtr alarm = getStandardField()->alarm();
static StructureConstPtr timeStamp = getStandardField()->timeStamp();
static FieldCreatePtr fieldCreate = getFieldCreate();

static void threeWays()
{
    cout << "hardest way\n";
    size_t n = 3;
    StringArray names;
    names.reserve(n);
    FieldConstPtrArray fields;
    fields.reserve(n);
    names.push_back("secsPastEpoch");
    fields.push_back(fieldCreate->createScalar(pvLong));
    names.push_back("nanoseconds");
    fields.push_back(fieldCreate->createScalar(pvInt));
    names.push_back("userTag");
    fields.push_back(fieldCreate->createScalar(pvInt));
    StructureConstPtr timeStamp = fieldCreate->createStructure(names,fields);
    size_t ntop = 2;
    StringArray topnames;
    topnames.reserve(ntop);
    FieldConstPtrArray topfields;
    topfields.reserve(ntop);
    topnames.push_back("value");
    topfields.push_back(fieldCreate->createScalar(pvDouble));
    topnames.push_back("timeStamp");
    topfields.push_back(timeStamp);
    StructureConstPtr doubleScalar = fieldCreate->createStructure(topnames,topfields);
    builder.clear();
    doubleScalar->toString(&builder);
    cout << builder << "\n\n";
    
    cout << "hardway\n";
    StructureConstPtr doubleScalarHard =
    getFieldCreate()->createFieldBuilder()->
        add("value",pvDouble) ->
        addNestedStructure("timeStamp")->
            setId("time_t")->
            add("secsPastEpoch", pvLong)->
            add("nanoseconds", pvInt)->
            add("userTag", pvInt)->
            endNested()->
        createStructure();
    builder.clear();
    doubleScalarHard->toString(&builder);
    cout << builder << "\n\n";

    cout << "easy way\n";
    StructureConstPtr stringArrayEasy = getStandardField()->scalarArray(pvString,"alarm,timeStamp");
    builder.clear();
    stringArrayEasy->toString(&builder);
    cout << builder << "\n\n";
}

static void enumExample()
{
    cout << "enum hard way\n";
    StructureConstPtr enum_t =
    fieldCreate->createFieldBuilder()->
        setId("enum_t")->
        add("index", pvInt)->
        addArray("choices", pvString)->
        createStructure();

    StructureConstPtr ntEnumHard =
    fieldCreate->createFieldBuilder()->
        setId("uri:ev4:nt/2012/pwd/NTEnum")->
        add("value", enum_t)->
        addNestedStructure("timeStamp")->
            setId("time_t")->
            add("secsPastEpoch", pvLong)->
            add("nanoseconds", pvInt)->
            add("userTag", pvInt)->
            endNested()->
        createStructure();
    builder.clear();
    ntEnumHard->toString(&builder);
    cout << builder << "\n\n";

    cout << "enum easy way\n";
    StructureConstPtr ntEnumEasy = getStandardField()->enumerated("alarm,timeStamp");
    builder.clear();
    ntEnumEasy->toString(&builder);
    cout << builder << "\n\n";
}

static void unionExample()
{
    cout << "union\n";
    UnionConstPtr punion =
    fieldCreate->createFieldBuilder()->
        add("doubleValue", pvDouble)->
        add("intValue", pvInt)->
        add("timeStamp",timeStamp)->
        createUnion();
    builder.clear();
    punion->toString(&builder);
    cout << builder << "\n\n";

    cout << "structure with value field being a union\n";
    StructureConstPtr unionValue = getStandardField()->regUnion(punion,"alarm,timeStamp");
    builder.clear();
    unionValue->toString(&builder);
    cout << builder << "\n\n";
}

static void powerSupplyExample()
{
    cout << "powerSupply\n";
    StructureConstPtr powerSupply =
    fieldCreate->createFieldBuilder()->
        add("alarm_t",alarm) ->
        add("timestamp_t",timeStamp) ->
        addNestedStructure("power") ->
           add("value",pvDouble) ->
           add("alarm",alarm) ->
           endNested()->
        addNestedStructure("voltage") ->
           add("value",pvDouble) ->
           add("alarm",alarm) ->
           endNested()->
        addNestedStructure("current") ->
           add("value",pvDouble) ->
           add("alarm",alarm) ->
           endNested()->
        createStructure();
    builder.clear();
    powerSupply->toString(&builder);
    cout << builder << "\n\n";
}

int main(int argc,char *argv[])
{
    threeWays();
    enumExample();
    unionExample();
    powerSupplyExample();
    return 0;
}
