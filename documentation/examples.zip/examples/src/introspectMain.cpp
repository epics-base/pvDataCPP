/*introspectMain.cpp */
/**
 * Copyright - See the COPYRIGHT that is included with this distribution.
 * EPICS pvData is distributed subject to a Software License Agreement found
 * in file LICENSE that is included with this distribution.
 */
/**
 * @author mrk
 */

/* Author: Marty Kraimer */

#include <cstddef>
#include <cstdlib>
#include <cstddef>
#include <string>
#include <cstdio>
#include <memory>
#include <iostream>

#include <pv/pvIntrospect.h>
#include <pv/pvData.h>
#include <pv/standardField.h>

using std::cout;
using std::endl;
using std::tr1::static_pointer_cast;
using namespace epics::pvData;
static FieldCreatePtr fieldCreate = getFieldCreate();
StandardFieldPtr standardField = getStandardField();

static void threeWays()
{
    cout << "hardest way\n";
    size_t n = 3;
    StringArray names;
    names.reserve(n);
    FieldConstPtrArray fields;
    fields.reserve(n);
    names.push_back("secondsPastEpoch");
    fields.push_back(fieldCreate->createScalar(pvLong));
    names.push_back("nanoSeconds");
    fields.push_back(fieldCreate->createScalar(pvInt));
    names.push_back("userTag");
    fields.push_back(fieldCreate->createScalar(pvInt));
    StructureConstPtr timeStamp = fieldCreate->createStructure(names,fields);
    size_t ntop = 2;
    StringArray topnames;
    topnames.reserve(ntop);
    FieldConstPtrArray topfields;
    topfields.reserve(ntop);
    topnames.push_back("value");
    topfields.push_back(fieldCreate->createScalar(pvDouble));
    topnames.push_back("timeStamp");
    topfields.push_back(timeStamp);
    StructureConstPtr doubleScalar =
        fieldCreate->createStructure(topnames,topfields);
    cout << doubleScalar->dump(cout) << "\n\n";
    
    cout << "hardway\n";
    StructureConstPtr doubleScalarHard =
    getFieldCreate()->createFieldBuilder()->
        add("value",pvDouble) ->
        addNestedStructure("timeStamp")->
            setId("time_t")->
            add("secondsPastEpoch", pvLong)->
            add("nanoSeconds", pvInt)->
            add("userTag", pvInt)->
            endNested()->
        createStructure();
    cout << doubleScalarHard->dump(cout) << "\n\n";

    cout << "easy way\n";
    StructureConstPtr stringArrayEasy = getStandardField()->scalarArray(pvString,"alarm,timeStamp");
    cout << stringArrayEasy->dump(cout) << "\n\n";
}

static void stringArrayValue()
{
    StructureConstPtr stringArrayEasy =
        standardField->scalarArray(pvString,"alarm,timeStamp");
    cout <<stringArrayEasy->dump(cout) << endl;
}

static void enumExample()
{
    cout << "enum hard way\n";
    StructureConstPtr enum_t =
    fieldCreate->createFieldBuilder()->
        setId("enum_t")->
        add("index", pvInt)->
        addArray("choices", pvString)->
        createStructure();

    StructureConstPtr ntEnumHard =
    fieldCreate->createFieldBuilder()->
        setId("uri:ev4:nt/2012/pwd/NTEnum")->
        add("value", enum_t)->
        addNestedStructure("timeStamp")->
            setId("time_t")->
            add("secondsPastEpoch", pvLong)->
            add("nanoSeconds", pvInt)->
            add("userTag", pvInt)->
            endNested()->
        createStructure();
    cout << ntEnumHard->dump(cout) << "\n\n";

    cout << "enum easy way\n";
    StructureConstPtr ntEnumEasy = getStandardField()->enumerated("alarm,timeStamp");
    cout << ntEnumEasy->dump(cout) << "\n\n";
}

static void unionExample()
{
    cout << "union\n";
    UnionConstPtr punion =
    fieldCreate->createFieldBuilder()->
        add("doubleValue", pvDouble)->
        add("intValue", pvInt)->
        add("timeStamp",standardField->timeStamp())->
        createUnion();
    cout << punion->dump(cout) << "\n\n";

    cout << "structure with value field being a union\n";
    StructureConstPtr unionValue = getStandardField()->regUnion(punion,"alarm,timeStamp");
    cout << unionValue->dump(cout) << "\n\n";
}

static void unionArrayExample()
{
    cout << "unionArray\n";
    UnionArrayConstPtr unionArray = fieldCreate->createUnionArray(
        fieldCreate->createVariantUnion());
    cout << unionArray->dump(cout) << "\n\n";
}

static void powerSupplyExample()
{
    cout << "powerSupply\n";
    StructureConstPtr powerSupply =
    fieldCreate->createFieldBuilder()->
        add("alarm_t",standardField->alarm()) ->
        add("timestamp_t",standardField->timeStamp()) ->
        addNestedStructure("power") ->
           add("value",pvDouble) ->
           add("alarm",standardField->alarm()) ->
           endNested()->
        addNestedStructure("voltage") ->
           add("value",pvDouble) ->
           add("alarm",standardField->alarm()) ->
           endNested()->
        addNestedStructure("current") ->
           add("value",pvDouble) ->
           add("alarm",standardField->alarm()) ->
           endNested()->
        createStructure();
    cout << powerSupply->dump(cout) << "\n\n";
}

int main(int argc,char *argv[])
{
    threeWays();
    stringArrayValue();
    enumExample();
    unionExample();
    unionArrayExample();
    powerSupplyExample();
    return 0;
}
